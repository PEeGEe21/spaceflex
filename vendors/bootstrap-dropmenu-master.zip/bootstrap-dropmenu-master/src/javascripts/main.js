$(function(){
	// Your code
});