// 
// GRUNT TASK: Style stats
// -----------------

module.exports = {
    dev: {
      src: ['docs/stylesheets/docs.css']
    },
    dist: {
      src: ['dist/stylesheets/bootstrap-dropmenu.css']
    }
}