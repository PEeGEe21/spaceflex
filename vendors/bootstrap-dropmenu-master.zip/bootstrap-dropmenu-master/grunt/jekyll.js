// 
// GRUNT TASK: Jekyll
// Build documentation from _config.yaml
// -----------------

module.exports = {
  build: {
  	baseurl: ''
  },  
};