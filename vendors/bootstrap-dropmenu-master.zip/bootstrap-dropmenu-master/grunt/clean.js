// 
// GRUNT TASK: Clean
// Clean task, removes all files and folders in /dist.
// -----------------

module.exports = {
	build: ['dist']
};