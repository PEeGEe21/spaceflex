// 
// GRUNT TASK: Shell
// Runs shell scripts
// -----------------

module.exports = {
  build: {
      command: 'jekyll build'
  },
  serve: {
      command: 'jekyll serve'
  }
};